package assignment5_vehicles;

public class Bike extends Vehicle {

    @Override
    public void start() {
        System.out.println("Bike engine starts with a kick or button.");
    }
}
