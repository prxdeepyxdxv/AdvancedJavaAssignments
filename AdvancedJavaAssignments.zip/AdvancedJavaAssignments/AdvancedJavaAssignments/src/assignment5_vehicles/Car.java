package assignment5_vehicles;

public class Car extends Vehicle {

    @Override
    public void start() {
        System.out.println("Car engine starts with a key.");
    }
}
