package assignment5_vehicles;

public class Vehicle {

    public void start() {
        System.out.println("Vehicle is starting.");
    }
}
