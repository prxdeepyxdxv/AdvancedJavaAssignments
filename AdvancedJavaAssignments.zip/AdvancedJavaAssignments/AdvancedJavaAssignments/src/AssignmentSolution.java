public class AssignmentSolution {

    public static void main(String[] args) {

        System.out.println("----- Method Overloading Demo -----");

        DataProcessor processor = new DataProcessor();
        processor.processData(10);
        processor.processData("HelloWorld");


        System.out.println("\n----- Method Overriding Demo -----");

        Animal genericAnimal = new Animal();
        genericAnimal.makeSound();

        Animal dog = new Dog();
        dog.makeSound();
    }
}


class DataProcessor {

    // Method Overloading - Integer Version
    public void processData(int number) {
        System.out.println("Processing integer data: " + number);
    }

    // Method Overloading - String Version (Chained)
    public void processData(String text) {
        System.out.println("Processing string data: " + text);
        int length = text.length();
        processData(length);
    }
}


class Animal {

    public void makeSound() {
        System.out.println("Animal makes a generic sound.");
    }
}


class Dog extends Animal {

    @Override
    public void makeSound() {
        System.out.println("Dog barks: Woof Woof!");
    }
}

