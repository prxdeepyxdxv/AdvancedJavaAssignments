package assignment6_employees;

public interface Payable {
    double calculatePay();
}
